import { Routes } from "@angular/router";
import { TabsPage } from "./tabs.page";

export const routes: Routes = [
  {
    path: "tabs",
    component: TabsPage,
    children: [
      {
        path: "tab1",
        loadComponent: () =>
          import("../account-list/account-list.component").then(
            (m) => m.AccountListComponent
          ),
      },
      {
        path: "transactions",
        loadComponent: () =>
          import("../transaction-list/transaction-list.component").then(
            (m) => m.TransactionListComponent
          ),
      },
      {
        path: "statement-uploader",
        loadComponent: () =>
          import("../statement-uploader/statement-uploader.component").then(
            (m) => m.StatementUploaderComponent
          ),
      },
      {
        path: "tab2",
        loadComponent: () =>
          import("../tab2/tab2.page").then((m) => m.Tab2Page),
      },
      {
        path: "tab3",
        loadComponent: () =>
          import("../tab3/tab3.page").then((m) => m.Tab3Page),
      },
      {
        path: "",
        redirectTo: "/tabs/tab1",
        pathMatch: "full",
      },
    ],
  },
  {
    path: "",
    redirectTo: "/tabs/tab1",
    pathMatch: "full",
  },
];
